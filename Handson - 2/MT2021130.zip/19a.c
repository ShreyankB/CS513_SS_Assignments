/*
    19. Create a FIFO file by :
        a. mknod command
*/

/*
command :
    mknod {--mode=permission} {filename} p

*/