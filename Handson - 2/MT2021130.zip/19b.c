/*
    19. Create a FIFO file by
        b. mkfifo command
*/

/*
command :
    mkfifo {--mode=permission} {filename} 

*/